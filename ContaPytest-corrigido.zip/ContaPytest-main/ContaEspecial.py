"""Conta bancária que permite utilizar um limite adicional."""

from ContaBancaria import ContaBancaria


class ContaEspecial(ContaBancaria):
    """Conta que permite saldo negativo até o limite contratado."""

    def __init__(
        self, titular: str, saldo_inicial: float = 0.0, limite: float = 500.0
    ):
        super().__init__(titular, saldo_inicial)
        self._validar_valor(limite, "O limite")
        if limite < 0:
            raise ValueError("O limite não pode ser negativo.")
        self.limite = float(limite)

    def sacar(self, valor: float) -> float:
        self._validar_valor(valor, "O valor do saque")
        if valor <= 0:
            raise ValueError("O valor do saque deve ser maior que zero.")
        if valor > self._saldo + self.limite:
            raise ValueError("Valor excede o limite disponível.")
        self._saldo -= float(valor)
        return self._saldo
