# ContaPytest

Projeto de exemplo com três tipos de conta bancária:

- `ContaBancaria`: depósitos e saques comuns.
- `ContaEspecial`: permite utilizar o limite adicional contratado.
- `ContaPoupanca`: permite aplicar rendimento percentual ao saldo.

## Como executar os testes

Com Python instalado, instale o pytest e execute na pasta do projeto:

```bash
python -m pip install pytest
python -m pytest -q
```

As operações validam valores numéricos, rejeitam valores inválidos ou negativos quando aplicável e retornam o saldo atualizado.
