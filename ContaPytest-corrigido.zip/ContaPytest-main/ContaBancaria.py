"""Implementação básica de uma conta bancária."""

import math


class ContaBancaria:
    """Classe base para os diferentes tipos de conta."""

    def __init__(self, titular: str, saldo_inicial: float = 0.0):
        if not isinstance(titular, str) or not titular.strip():
            raise ValueError("O titular deve ser informado.")
        self._validar_valor(saldo_inicial, "O saldo inicial")
        if saldo_inicial < 0:
            raise ValueError("O saldo inicial não pode ser negativo.")
        self.titular = titular.strip()
        self._saldo = float(saldo_inicial)

    @staticmethod
    def _validar_valor(valor: float, descricao: str = "O valor") -> None:
        if isinstance(valor, bool) or not isinstance(valor, (int, float)):
            raise ValueError(f"{descricao} deve ser um número válido.")
        if not math.isfinite(valor):
            raise ValueError(f"{descricao} deve ser um número válido.")

    @property
    def saldo(self) -> float:
        return self._saldo

    def depositar(self, valor: float) -> float:
        self._validar_valor(valor, "O valor do depósito")
        if valor <= 0:
            raise ValueError("O valor do depósito deve ser maior que zero.")
        self._saldo += float(valor)
        return self._saldo

    def sacar(self, valor: float) -> float:
        self._validar_valor(valor, "O valor do saque")
        if valor <= 0:
            raise ValueError("O valor do saque deve ser maior que zero.")
        if valor > self._saldo:
            raise ValueError("Saldo insuficiente para realizar o saque.")
        self._saldo -= float(valor)
        return self._saldo
