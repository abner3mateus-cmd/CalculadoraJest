"""Conta poupança com funcionalidade de rendimento."""

from ContaBancaria import ContaBancaria


class ContaPoupanca(ContaBancaria):
    """Herda as operações bancárias e permite aplicar juros ao saldo."""

    def render_juros(self, taxa: float) -> float:
        self._validar_valor(taxa, "A taxa de juros")
        if taxa < 0:
            raise ValueError("A taxa de juros não pode ser negativa.")
        self._saldo *= 1 + float(taxa)
        return self._saldo
